public class Checkerboard { // start class
    public static void main(String[] args) { // start main
    	
        int n = Integer.parseInt(args[0]);
        
        for(int i = 0; i < n; i++) { // start loop0
            for(int j = 0; j < n; j++) { // start loop1
                if(i % 2 == 0)
                    System.out.print("* ");
                else
                    System.out.print(" *");
                } // end loop1
            System.out.println();
            } // end loop0
        
    } // end main
} // end class