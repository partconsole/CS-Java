public class Ordered { // start class
    public static void main(String[] args) { // start main
    	
        int x = Integer.parseInt(args[0]);
        int y = Integer.parseInt(args[1]);
        int z = Integer.parseInt(args[2]);

        boolean isOrdered = (x < y && y < z); 

        System.out.println(isOrdered);
        
    } // end main
} // end class
