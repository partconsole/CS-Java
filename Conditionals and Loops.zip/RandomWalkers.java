public class RandomWalkers { // start class
    public static int RandomWalker(int n) { // start main 0
    	
        int x = 0;
        int	y = 0;
        for(int i = 0; i < n; i++)
        { // start loop
            double rand = Math.random();
            if(rand < 0.25)
                ++x; // move right
            else if(rand < 0.5)
                --y; // move up
            else if(rand < 0.75)
                --x; // move left
            else if(rand < 1.0)
                ++y;
        } // end loop
        return x*x + y*y;
        
    } // end main 0
    
    public static void main(String[] args) { // start main 1
        int n = Integer.parseInt(args[0]);
        int t = Integer.parseInt(args[1]);

        double mean = 0;
        for(int i = 0; i < t; i++) { // start loop
            mean += RandomWalker(n); 
            } // end loop
        
        System.out.println("mean squared distance = " + mean/t);
        
    } // end main 1
    
} // end class