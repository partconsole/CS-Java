public class RandomWalker { // start class
    public static void main(String[] args) { // start main
    	
        int n = Integer.parseInt(args[0]);
        int x = 0;
        int y = 0;
        
        for(int i = 0; i < n; i++) { // start loop
        	double rand = Math.random();
            if(rand < 0.25)
                ++x; // move right
            else if(rand < 0.5)
                --y; // move up
            else if(rand < 0.75)
                --x; // move left
            else if(rand < 1.0)
                ++y;
            System.out.println("(" + x + ", " + y + ")"); 
            } // end loop
        
        System.out.println("squared distance = " + (x*x + y*y));
        
    } // end main
} // end class