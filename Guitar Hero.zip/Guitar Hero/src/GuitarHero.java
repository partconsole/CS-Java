public class GuitarHero {
	public static void main(String[] args) {
		String keyboard = "q2we4r5ty7u8i9op-[=zxdcfvgbnjmk,.;/' "; // provided string keyboard
		GuitarString[] sound = new GuitarString[keyboard.length()];

		// calculates the different frequencies for the given key
		for (int i = 0; i < 37; i++) {
			double freq = 440 * (Math.pow(1.05956, (i - 24)));
			sound[i] = new GuitarString(freq);
		}

		while (true) { // start while
			if (StdDraw.hasNextKeyTyped()) {
				char key = StdDraw.nextKeyTyped(); // grabs key that user types
				int key_ind = keyboard.indexOf(key);
				if (key_ind != -1) { // if the key is on the keyboard, play the sound
					sound[key_ind].pluck();
				}
			}
			// go through each GuitarString in 'sound' and do .sample() and add it to an
			// accumulator
			double sample = 0.0;
			for (int i = 0; i < 37; i++) {
				sample += sound[i].sample();
			}

			// play the sample on standard audio
			StdAudio.play(sample);

			// tic
			for (int i = 0; i < 37; i++) {
				sound[i].tic();
			}

		} // end while
	}
}