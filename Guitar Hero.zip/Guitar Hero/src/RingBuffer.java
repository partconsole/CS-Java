public class RingBuffer {
	// instance variables
	int first; // the index for the first element of the queue
	int size; // the size of the queue, last = first + size - 1
	double[] queue; // the array for the queue
	int capacity; // the capacity of the array

	public RingBuffer(int capacity) { // create an empty ring buffer, with (max) capacity
		this.capacity = capacity;
		queue = new double[capacity];
		size = 0;
		first = 0;
	}

	int size() { // return current number of items in the buffer
		return size;
	}

	boolean isEmpty() { // return size = 0 if empty
		return (size == 0);
	}

	boolean isFull() { // return size = capacity if full
		return (size == capacity);
	}

	void enqueue(double x) { // add item to the end
		if (size == capacity)
			throw new RuntimeException("It's already Full!!!");
		else {
			queue[(first + size) % capacity] = x;
			size++;
		}
	}

	double dequeue() { // delete and return item from the front
		// put a run time error if I attempt to dequeue when the queue is empty
		if (isEmpty())
			throw new RuntimeException("It's already Empty!!!");
		else {
			double oldfirst = queue[first]; // this remembers the item I'm about to pop out
			first++;
			size--;
			if (first == capacity)
				first = 0;
			return oldfirst;
		}
	}

	double peek() { // return front item
		return queue[first];
	}

	public static void main(String[] args) {
	}
}