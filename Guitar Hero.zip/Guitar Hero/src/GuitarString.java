public class GuitarString {
	int samplingRate = 44100;
	int N;
	RingBuffer ring;
	int counter; // for the time function
	// Conductors:

	/*
	 * Creates a RingBuffer with capacity N, derived from sampling rate 44,100
	 * divided by frequency. Initializes the buffer with N zeros to represent a
	 * guitar string at rest.
	 */

	GuitarString(double frequency) { // create a guitar string of a frequency with the sampling rate (44,100)
		counter = 0;
		N = (int) Math.ceil(samplingRate / frequency);
		ring = new RingBuffer(N);
		for (int i = 0; i < N; i++) {
			ring.enqueue(0.0);
		}
	}

	/*
	 * Creates a RingBuffer with capacity equal to size of the array. Initializes
	 * the contents of the buffer to the values in the array.
	 */
	GuitarString(double[] init) { // create guitar string with size and initial values given in the array
		counter = 0;
		N = init.length;
		ring = new RingBuffer(N);
		for (int i = 0; i < N; i++) {
			ring.enqueue(init[i]);
		}
	}

	/*
	 * Replace N items in the ring buffer with N random values between -0.5 and +0.5
	 */
	void pluck() { // set buffer to white noise
		for (int i = 0; i < N; i++) {
			double rand = (Math.random() - 0.5);
			ring.dequeue();
			ring.enqueue(rand);
		}
	}

	/*
	 * Karplus-Strong algorithm: takes the first two numbers, averages them, then
	 * multiplies them by the energy decay factor, then adds that to the end.
	 */
	void tic() { // advance the simulation one time step
		counter += 1;
		double current = ring.peek(); // takes the first number
		ring.dequeue();// dequeue first number
		double second = ring.peek();// takes the second
		double avg = .5 * (current + second);
		ring.enqueue(.994 * avg);// energy decay factor*average
	}

	/*
	 * Return the value of the item at the front of the ring buffer.
	 */
	double sample() { // return the current sample
		return ring.peek();
	}

	/*
	 * Return the total number of times tic() was called.
	 */
	int time() { // return number of tics
		return counter;
	}

	public static void main(String[] args) {
	}
}