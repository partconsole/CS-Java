/**********************************************************************
 *  readme.txt template                                                   
 *  Plucking a Guitar String
 **********************************************************************/

Name: Minh Tran

Hours to complete assignment (optional):


/**********************************************************************
 *  Explain why it makes sense to have a separate RingBuffer class.
 **********************************************************************/
It is basically a personalized library like stdlibs that we can use the
built in functions that we "built", similar to pre-built in functions 
like math.something() ... which we makes the code look a lot more clean 
and nice, and we don't have to code them out individually on 
GuitarString and Guitar Hero.


/**********************************************************************
 *  If you did one of the extra credits, name which one you did, 
 *  describe it here and write why it is interesting.
 **********************************************************************/


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/


/**********************************************************************
 *  List whatever help (if any) that you received. You don't need to
 *  include the course materials or lectures, but do include any
 *  additional help your received from people other than course staff,
 *  and include their names.
 **********************************************************************/
