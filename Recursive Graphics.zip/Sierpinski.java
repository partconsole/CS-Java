public class Sierpinski {

    public static void triangle(double x0, double y0, double x1, double y1, double x2, double y2) {
        // Draw triangle
        StdDraw.line(x0, y0, x1, y1);
        StdDraw.line(x1, y1, x2, y2);
        StdDraw.line(x2, y2, x0, y0);
    }

    public static void sierpinski(double x0, double y0, double x1, double y1, double x2, double y2, int level) {
        // Draw the current triangle
        triangle(x0, y0, x1, y1, x2, y2);
        
        // Base case
        if (level > 0) {
            // Calculate midpoints
            double midX01 = (x0 + x1) / 2;
            double midY01 = (y0 + y1) / 2;
            double midX12 = (x1 + x2) / 2;
            double midY12 = (y1 + y2) / 2;
            double midX20 = (x2 + x0) / 2;
            double midY20 = (y2 + y0) / 2;
            
            // Call function
            sierpinski(x0, y0, midX01, midY01, midX20, midY20, level - 1);
            sierpinski(midX01, midY01, x1, y1, midX12, midY12, level - 1);
            sierpinski(midX20, midY20, midX12, midY12, x2, y2, level - 1);
        }
    }

    public static void main(String[] args) {
        // Testing
        double x0 = 0;
        double y0 = 0;
        double x1 = 1;
        double y1 = 0;
        double x2 = 0.5;
        double y2 = 0.866;
        int level = 5;
        
        // Draw 
        sierpinski(x0, y0, x1, y1, x2, y2, level);
    }
}
