public class Idontknowlol {

    public static void stick(double x0, double y0, double x1, double y1) {
        // Draw the main stick
        StdDraw.line(x0, y0, x1, y1);
        
        // Calculate position for substicks
        double midX = (x0 + x1) / 2;
        double midY = (y0 + y1) / 2;
        double branchLength = Math.sqrt(Math.pow(x1 - x0, 2) + Math.pow(y1 - y0, 2)) / 3; // Length 
        
        // Draw 3 sticks grow out of the main stick
        StdDraw.line(midX - branchLength, midY, midX + branchLength, midY); // Middle stick
        StdDraw.line(midX - branchLength / 2, midY + branchLength / 2, midX, midY); // Left stick
        StdDraw.line(midX, midY, midX + branchLength / 2, midY + branchLength / 2); // Right stick
    }

    public static void idontknowokay(double x0, double y0, double x1, double y1, int level) {
        stick(x0, y0, x1, y1);
        
        // Base case
        if (level > 0) {
            // Calculate positions for the substicks
            double midX = (x0 + x1) / 2;
            double midY = (y0 + y1) / 2;
            double branchLength = Math.sqrt(Math.pow(x1 - x0, 2) + Math.pow(y1 - y0, 2)) / 3; // Length of the substicks
            
            // Endpoints for the substicks
            double x2 = midX - branchLength;
            double y2 = midY;
            double x3 = midX + branchLength;
            double y3 = midY;
            double x4 = midX;
            double y4 = midY + branchLength / 2;
            
            // Call idontknowokay function 
            idontknowokay(midX, midY, x2, y2, level - 1); // Middle stick
            idontknowokay(midX, midY, x3, y3, level - 1); // Left stick
            idontknowokay(midX, midY, x4, y4, level - 1); // Right stick
        }
    }

    public static void main(String[] args) {
        // Testing
        double x0 = 0.5;
        double y0 = 0;
        double x1 = 0.5;
        double y1 = 0.8;
        int level = 5;
        
        // Draw 
        idontknowokay(x0, y0, x1, y1, level);
    }
}
