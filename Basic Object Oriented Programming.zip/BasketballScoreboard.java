public class BasketballScoreboard implements Scoreboard {
	public int homeScore;
	public int guestScore;
	public int defaultScoreValue = 2;
	public String homeName;
	public String guestName;

	public BasketballScoreboard() {
		homeName = "home";
		guestName = "guest";
	}

	public BasketballScoreboard(String homeName, String guestName) {
		this.homeName = homeName;
		this.guestName = guestName;
	}

	public void homeScored() {// add default score
		homeScore = homeScore + defaultScoreValue;
	}

	public void guestScored() {// add default score
		guestScore = guestScore + defaultScoreValue;
	}

	public String toString() {
		return (homeName + ": " + homeScore + "\n" + guestName + ": " + guestScore);
	}

	public static void main(String[] args) {
	}
}