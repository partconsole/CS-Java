public interface Scoreboard {
	public void homeScored(); 
	public void guestScored(); 
}