public class RealBasketballScoreboard extends BasketballScoreboard {

	public RealBasketballScoreboard() {
		super();
	}

	public RealBasketballScoreboard(String homeName, String guestName) {
		super(homeName, guestName);
	}

	public void homeScored(int scoreValue) {
		if (scoreValue < 1 || scoreValue > 3)
			throw new RuntimeException("scoreValue must be 1,2, or 3");
		homeScore += scoreValue;
	}

	public void guestScored(int scoreValue) {
		if (scoreValue < 1 || scoreValue > 3)
			throw new RuntimeException("scoreValue must be 1,2, or 3");
		guestScore += scoreValue;
	}
}