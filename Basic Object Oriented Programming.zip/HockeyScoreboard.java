public class HockeyScoreboard implements Scoreboard {
	public int homeScore;
	public int guestScore;
	public int defaultScoreValue = 1;
	public String homeName;
	public String guestName;

	public HockeyScoreboard() {
		homeName = "home";
		guestName = "guest";
	}

	public HockeyScoreboard(String homeName, String guestName) {
		this.homeName = homeName;
		this.guestName = guestName;
	}

	public void homeScored() {
		homeScore = homeScore + defaultScoreValue;
	}

	public void guestScored() {
		guestScore = guestScore + defaultScoreValue;
	}

	public String toString() {
		return (homeName + ": " + homeScore + "\n" + guestName + ": " + guestScore);
	}
}