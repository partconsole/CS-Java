/**********************************************************************
 *  readme template
 *  Global Sequence Alignment
 **********************************************************************/

Name: Minh Tran

Hours to complete assignment (optional):

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
I just got it to run after trying again.

/**********************************************************************
 *  Make a table of values showing running times for the method
 *  recursiveEditDistance when given two random DNA strings of length
 *  N, where N from 1 to about 10 or 12.  To do this properly, it would
 *  be best to repeat the test several times for each value of N, and
 *  average the times.
 *
 *  What can you say about the growth of this time as a function of N?
 *  
 **********************************************************************/
N	Edit Distance (avg.)	   Avg. Time(sec)
1		1			0.0
2		1			0.0
3		2			0.0
4		2			0.001
5		3			0.075
6		5			0.007
8		9			0.031
9		9			0.954
11		7			0.121
12		8			1.5043
13		9			5.373

As N increases, the ratio from the time of N to 2*N increases 
inconsistently and exponetially.

/**********************************************************************
 *  For each data file, fill in the edit distance computed by your
 *  program and the amount of time it takes to compute it.
 **********************************************************************/

data file           distance       time (seconds)
-------------------------------------------------
ecoli3000.txt		125		.093
ecoli5000.txt		160		.224
ecoli7000.txt		194		.452
ecoli10000.txt		223		.822


/**********************************************************************
 *  Because the dynamic programming version does a fixed amount of
 *  computation for each element in the two-dimensional table,
 *  we expect that the time complexity should be quadratic.  Does the
 *  data above seem to support this hypothesis?   Use the doubling
 *  hypothesis to explain how you arrived at your answer.
 **********************************************************************/
The numbers show that dynamic programing is faster on average. When using 
the doubling hypothesis, N increases the ratio of 2*N to N increases. 

/**********************************************************************
 *  As a function of the string length N (assume M = N), estimate the
 *  running time of your program (and the sample) in seconds. Your answer
 *  should have the form a * N^2 for some constant a.
 *
 *  What is the largest N your program can handle if it is limited to 1
 *  day of computation? Assume you have as much main memory as you need.
 **********************************************************************/
largest N =2939387
table for solving for a:
.83=a *10000^2	=0.000000083
.39=a *7000^2	=0.00000000796
.234=a *5000^2	=0.00000000936
.086=a *3000^2  =0.00000000956

/**********************************************************************
 *  List whatever help (if any) that you received. You don't need to
 *  include the course materials or lectures, but do include any
 *  additional help your received from people other than course staff,
 *  and include their names.
 **********************************************************************/


/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/