import java.io.FileInputStream; // put this at the top of your source code outside the class definition

public class EditDistance {

	public static void main(String[] args) { // start main

		// read from the data files included in sequence.zip
		try {

			System.setIn(new FileInputStream("resources/" + args[0]));

		} catch (Exception e) {

			System.err.printf("Exception caught: %s\n", e.toString());

			System.exit(0);
		}
		
		
		
		String x = StdIn.readLine();
		
		String y = StdIn.readLine();
		
		
		printEditDistance(x, y);
		timeEditDistance(x, y);
		
        // random DNA strings and compute edit distance
        for (int i = 1; i <= 13; i++) {
            String randomX = randomDNAString(i);
            String randomY = randomDNAString(i);
            System.out.println("Length " + i );

            System.out.println("recursiveEditDistance: ");
            timeRecursiveEditDistance(randomX, randomY);
        }
		
	} // end main

	/**

	 * @param x a non-null String

	 * @param y a non-null String

	 * @return the the edit distance between x and y

	 * 

	 * This procedure should use a recursive, not dynamic programming, approach

	 * to compute the edit distance

	 */

	private static int recursiveEditDistance(String x, String y) {
		// suffixes starting at 0, 0 = the whole strings
		return recursiveEditDistance(x, y, 0, 0);
	}

	private static int recursiveEditDistance(String x, String y, int i, int j) {// start recursiveEditDistance
		// base cases
		if (i == x.length())
			return (y.length() - j) * 2;
		if (j == y.length())
			return (x.length() - i) * 2;
		// recursive cases
		int option1 = recursiveEditDistance(x, y, i + 1, j) + 2;// option1 skips the value to the right and adds 2
		int option2 = recursiveEditDistance(x, y, i, j + 1) + 2;// option2 bottom
		int option3 = recursiveEditDistance(x, y, i + 1, j + 1);// option3 down
		if (x.charAt(i) != y.charAt(j))
			option3 = option3 + 1; // one character in common
		return Math.min(option1, Math.min(option2, option3));
	}// end recursiveEditDistance

	/**

	 * @param x a non-null String

	 * @param y a non-null String

	 * @return the the edit distance between x and y

	 * 

	 * This procedure should dynamic programming to compute the edit distance

	 */

	private static int editDistance(String x, String y) {
		int[][] opt = editDistanceTable(x, y);// makes table
		return opt[0][0];
	}// 

	private static int[][] editDistanceTable(String x, String y) {// makes table for dpLCS lengths
		int[][] opt = new int[x.length() + 1][y.length() + 1];
		// fill table opt
		for (int i = x.length(); i >= 0; i--) { // start for 1
			for (int j = y.length(); j >= 0; j--) { // start for 2
				if (i == x.length()) {// adds 2 to right side of the table from bottom to top
					opt[i][j] = (y.length() - j) * 2;
				} else if (j == y.length()) {// adds 2 to bottom side of the table from right to left
					opt[i][j] = (x.length() - i) * 2;
				} else { // start else
					int option1 = opt[i + 1][j] + 2; // opt1 takes the value to the right and adds 2
					int option2 = opt[i][j + 1] + 2; // opt2 takes the value below and adds 2
					int option3 = opt[i + 1][j + 1]; // opt3 takes the value to the bottom right diagonally
					if (x.charAt(i) != y.charAt(j)) { // if char is different, adds one
						option3++;
					} // end if 
					opt[i][j] = Math.min(option1, Math.min(option2, option3));
				} // end else
			} // end for 2
		} // end for 1
		return opt; // return entire table "opt"
	}// end editDistanceTable

	/**

	 * @param x a non-null String

	 * @param y a non-null String

	 * 

	 * This procedure should use dynamic programming to compute the edit distance

	 * and print it and an optimal alignment in the vertical format shown in the

	 * project assignment.

	 * NOTE: There may be multiple optimal alignments.

	 *       This procedure needs to print one optimal alignment.

	 */

	private static void printEditDistance(String x, String y) { // start printEditDistance
		System.out.println("Edit distance = " + editDistance(x, y));
		int[][] opt = editDistanceTable(x, y);// return table opt
		String editX = "";
		String editY = "";
		int indX = 0;
		int indY = 0;

		while (indX < x.length() && indY < y.length()) { // start first while
			if (opt[indX][indY] == opt[indX + 1][indY] + 2) {// adds gap matched with x
				editX += x.charAt(indX);
				editY += '-';
				indX++;
			} else if (opt[indX][indY] == opt[indX][indY + 1] + 2) { // adds gap matched with y
				editY += y.charAt(indY);
				editX += '-';
				indY++;
			} else if (x.charAt(indX) == y.charAt(indY)) { // when x and y are equal
				editX += x.charAt(indX);
				editY += y.charAt(indY);
				indX++;
				indY++;
			} else { // and when x and y are not equal 
				editX += x.charAt(indX);
				editY += y.charAt(indY);
				indX++;
				indY++;
			}
		} // end first while

		// print the editX and editY strings vertically with score
		for (int i = 0; i < Math.max(x.length(), y.length()); i++) {
			System.out.print(editX.charAt(i) + " " + editY.charAt(i));
			// if there is a '-' and prints  2
			if (editX.charAt(i) == '-' || editY.charAt(i) == '-') {
				System.out.println("  2");
			}
			// if the two are different, prints 1
			else if (editX.charAt(i) != editY.charAt(i)) {
				System.out.println("  1");
			}
			// if the two are equal, prints 0
			else if (editX.charAt(i) == editY.charAt(i)) {
				System.out.println("  0");
			}
		} // end for loop
	}// end printEditDistance

	/**

	 * @param x a non-null String

	 * @param y a non-null String

	 * 

	 * Prints out the edit distance between x and y and the time taken to compute it

	 * using the recursive version recursiveEditDistance

	 */

	public static void timeRecursiveEditDistance(String x, String y) {
		Stopwatch sw = new Stopwatch();// initializes Stopwatch
		int len = recursiveEditDistance(x, y);// calls recursive function to find LCS
		double time = sw.elapsedTime();// tracks time
		System.out.println("Edit distance is " + len + " and it took Memo " + time + " seconds");
	}
	
	
	/**

	 * @param x a non-null String

	 * @param y a non-null String

	 * 

	 * Prints out the edit distance between x and y and the time taken to compute it

	 * using the dynamic programming version editDistance

	 */

	public static void timeEditDistance(String x, String y) {
		Stopwatch sw = new Stopwatch();// initializes stopwatch
		int len = editDistance(x, y);// calls recursive function to find LCS
		double time = sw.elapsedTime();// tracks time
		System.out.print("Edit distance is " + len + " and it took DP " + time + " seconds");
	}

	/**

	 * @param dnaLength a non-negative int

	 * @return a random String of length dnaLength comprised of the four chars A, T, G, and C

	 */

	public static String randomDNAString(int dnaLength) {
		String DNAString = "";
		for (int i = 1; i <= dnaLength; i++) {
			double rnd = Math.random();
			if (rnd < .25)
				DNAString += "A";
			else if (rnd < .5)
				DNAString += "T";
			else if (rnd < .75)
				DNAString += "G";
			else
				DNAString += "C";
		}
		return DNAString;
	}

}
